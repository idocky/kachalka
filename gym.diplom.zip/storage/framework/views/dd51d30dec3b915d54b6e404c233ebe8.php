<div <?php echo e($attributes
        ->class([
            'my-4',
        ]), false); ?>></div>
<?php /**PATH C:\OSPanel\domains\gym.diplom\vendor\moonshine\moonshine\src\Providers/../../resources/views/decorations/line-break.blade.php ENDPATH**/ ?>