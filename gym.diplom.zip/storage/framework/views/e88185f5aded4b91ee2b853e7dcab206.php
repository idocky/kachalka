<div <?php echo e($attributes->merge(['class' => 'grid grid-cols-12 gap-6']), false); ?>>
    <?php echo e($slot, false); ?>

</div>
<?php /**PATH C:\OSPanel\domains\gym.diplom\vendor\moonshine\moonshine\src\Providers/../../resources/views/components/grid.blade.php ENDPATH**/ ?>