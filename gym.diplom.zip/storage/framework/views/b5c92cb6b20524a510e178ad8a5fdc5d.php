<textarea <?php echo e($attributes->merge([
    'class' => 'form-textarea',
    ]), false); ?>

><?php echo e($slot, false); ?></textarea>
<?php /**PATH C:\OSPanel\domains\gym.diplom\vendor\moonshine\moonshine\src\Providers/../../resources/views/components/form/textarea.blade.php ENDPATH**/ ?>