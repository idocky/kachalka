<div class="heading">
    <<?php echo e($element->getTag(), false); ?> <?php echo e($attributes, false); ?>>
        <?php echo e($element->label(), false); ?>

    </<?php echo e($element->getTag(), false); ?>>
</div>
<?php /**PATH C:\OSPanel\domains\gym.diplom\vendor\moonshine\moonshine\src\Providers/../../resources/views/decorations/heading.blade.php ENDPATH**/ ?>