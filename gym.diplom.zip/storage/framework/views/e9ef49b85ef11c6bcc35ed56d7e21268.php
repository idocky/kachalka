<?php $__env->startSection('content'); ?>
    <main role="main">

        <section class="wt-section bg-light mt-5" id="services">
            <div class="container">
                <div class="row justify-content-md-center text-center pb-lg-4 mb-lg-5 mb-4">
                    <div class="col-md-8 text-center w-md-50 mx-auto mb-0 ">
                        <h2 class="mb-md-2 mt-5">Наші секції</h2>
                        <p class="lead text-muted">Наша мережа має безліч різних спортивних заходів, які напевно припадуть вам до душі</p>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <?php $__currentLoopData = $workout_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <div class="card mb-md-0 mb-3 border-1 rounded-md overflow-hidden b-hover" data-aos="fade-up"  data-aos-easing="linear" data-aos-delay="300">
                                <a href="#"><img class="card-img-top" src="<?php echo e(asset('storage/' . $type->image), false); ?>" alt="card image"></a>
                                <div class="card-body py-4">
                                    <h5 class="mb-4 text-primary"><?php echo e($type->title, false); ?></h5>
                                    <div class="mb-4">
                                        <p><?php echo e($type->description, false); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>

        <section class="wt-section pb-0" id="about">
            <div class="container">
                <div class="row justify-content-between align-items-center" data-aos="fade-right" data-aos-easing="linear" data-aos-delay="200">
                    <div class="col-md-5">
                        <img src="<?php echo e(asset('img/about/1.jpg'), false); ?>" width="90%" class="rounded-md" alt="">
                    </div>
                    <div class="col-md-7">
                        <h2 class="mb-4 ">Про нас</h2>
                        <p class="text-muted">Наша команда - це сплочений колектив, який працює на результат. Ми пройшли складний шлях розвитку і зарекомендували себе як надійний партнер у сфері інноваційних технологій. Наша місія - створювати продукти, які відповідають потребам сучасного ринку та сприяють досягненню успіху наших клієнтів.</p>
                    </div>

                </div>
            </div>
        </section>

        <section class="wt-section">
            <div class="container">
                <div class="row justify-content-between align-items-center" data-aos="fade-left" data-aos-easing="linear" data-aos-delay="400">
                    <div class="col-md-7">
                        <h2 class="mb-4">Професійна команда</h2>
                        <p class="text-muted">Наші фахівці - це професіонали своєї справи з багаторічним досвідом у сфері розробки програмного забезпечення. Кожен член нашої команди має високі стандарти роботи та надзвичайну увагу до деталей.</p>
                    </div>

                    <div class="col-md-5">
                        <img src="<?php echo e(asset('img/about/2.jpg'), false); ?>" width="90%" class="rounded-md" alt="">
                    </div>
                </div>
            </div>
        </section>
        <section class="wt-section bg-primary">
            <div class="container">
                <div class="row justify-content-md-center text-center pb-lg-4 mb-lg-5 mb-4">
                    <div class="col-md-8 text-center w-md-50 mx-auto mb-0 ">
                        <h2 class="mb-md-2">Зручності</h2>

                    </div>
                </div>
                <!-- Feature Blocks -->
                <div class="row">
                    <div class="col-md-4">
                        <div class="bg-white p-5 mb-4 text-center rounded-md overflow-hidden b-hover" data-aos="fade-up"  data-aos-easing="linear" data-aos-delay="300">
                            <i class="ti-share-alt display-4 d-block text-primary mb-4"></i>
                            <h6 class="my-2">Парова баня</h6>
                            <p class="text-muted">Зануртесь в світ розслаблення з нашою наявною паровою банею, де ви зможете насолоджуватися відпочинком і очищенням тіла.</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="bg-white p-5 mb-4 text-center rounded-md overflow-hidden b-hover" data-aos="fade-up"  data-aos-easing="linear" data-aos-delay="500">
                            <i class="ti-pulse display-4 d-block text-primary mb-4"></i>
                            <h6 class="my-2">Wi-Fi</h6>
                            <p class="text-muted">Насолоджуйтесь комфортом з нашим швидким Wi-Fi</p>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="bg-white p-5 mb-4 text-center rounded-md overflow-hidden b-hover" data-aos="fade-up"  data-aos-easing="linear" data-aos-delay="800">
                            <i class="ti-panel display-4 d-block text-primary mb-4"></i>
                            <h6 class="my-2">Вентиляція</h6>
                            <p class="text-muted">Наша відмінна система вентиляції забезпечить свіжий та чистий повітря, що додасть вашому досвіду максимальний комфорт.</p>
                        </div>
                    </div>
                </div>
                <!-- End Feature Blocks -->
            </div>
        </section>

        <section class="bg-light wt-section" id="team">
            <div class="container">
                <div class="row justify-content-md-center text-center mb-lg-5 mb-4 pb-lg-5">
                    <div class="col-md-12">
                        <h2 class="h1">Наша команда</h2>
                        <p>У нас працюють найкращі з найкращих</p>
                    </div>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $coaches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-sm-6 mb-5">
                            <figure data-aos="fade-up" data-aos-easing="linear" data-aos-delay="100">
                                <img class="w-100 rounded-top" src="<?php echo e(asset('storage/' . $coach->image), false); ?>" alt="Image Description">
                                <div class="wt-box-shadow-sm bg-white text-center rounded p-4">
                                    <div class="mb-3">
                                        <h5 class="mb-1"><?php echo e($coach->full_name, false); ?></h5>
                                        <small class="d-block font-style-normal text-uppercase text-primary wt-letter-spacing-xs">Стаж: <?php echo e($coach->experience, false); ?> років</small>
                                    </div>
                                </div>
                            </figure>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
        <div class="wt-section" id="price">
            <div class="container">
                <div class="row justify-content-md-center text-center mb-lg-5 mb-4 pb-lg-5">
                    <div class="col-md-12">
                        <h2 class="h1">Ціни & Графік</h2>
                    </div>
                </div>
                <div class="container mt-5 row justify-content-md-center text-center mb-lg-5 pb-lg-5">
                    <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workout_date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="btn-group m-2" role="group">
                            <button type="button" class="btn btn-secondary date-button" data-date="<?php echo e($workout_date[0], false); ?>"><?php echo e($workout_date[1], false); ?></button>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table class="table custom-table table-borderless">
                                <thead>
                                <tr>
                                    <th>Час</th>
                                    <th>Заняття</th>
                                    <th>Тренер</th>
                                    <th>Ціна</th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $workouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr data-aos="fade-in" data-aos-easing="linear" data-aos-delay="200">
                                            <td><?php echo e($workout->start_time->format('H:i'), false); ?> - <?php echo e($workout->end_time->format('H:i'), false); ?></td>
                                            <td>
                                                <h6><?php echo e($workout->workout_types->title, false); ?></h6>
                                                <span class="text-muted"><?php echo e($workout->place, false); ?></span>
                                            </td>
                                            <td>
                                                <h6><?php echo e($workout->coaches->full_name, false); ?></h6>
                                            </td>
                                            <td>
                                                <h6><?php echo e($workout->price, false); ?> ₴</h6>
                                            </td>
                                            <td>
                                                <?php if($workout->user_id): ?>
                                                    <div class="btn btn-secondary btn-pill">Зайнято</div>
                                                <?php else: ?>
                                                    <a href="#" class="btn btn-primary btn-pill join-workout" data-workout-id="<?php echo e($workout->id, false); ?>">Приєднатися</a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <section class="bg-dark position-relative pt-5">
            <div class="container">
                <div class="row text-center text-uppercase text-white">
                    <div class="col-lg-3 col-sm-6 pb-5">
                        <h5 class="js-counter display-4 mb-1">15</h5>
                        <small class="d-block font-style-normal text-uppercase wt-letter-spacing-sm">Тренери</small>
                    </div>

                    <div class="col-lg-3 col-sm-6 pb-5">
                        <h5 class="js-counter display-4 mb-1">114</h5>
                        <small class="d-block font-style-normal text-uppercase wt-letter-spacing-sm">Обладнання</small>
                    </div>

                    <div class="col-lg-3 col-sm-6 pb-5">
                        <h5 class="js-counter display-4 mb-1">245</h5>
                        <small class="d-block font-style-normal text-uppercase wt-letter-spacing-sm">Клієнти</small>
                    </div>

                    <div class="col-lg-3 col-sm-6 pb-5">
                        <h5 class="js-counter display-4 mb-1">2</h5>
                        <small class="d-block font-style-normal text-uppercase wt-letter-spacing-sm">Кофетерії</small>
                    </div>
                </div>
            </div>
        </section>


    </main>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.join-workout').click(function(e) {
                e.preventDefault();
                var button = $(this);
                var workoutId = button.data('workout-id');
                $.ajax({
                    url: '/assignClientToWorkout/' + workoutId,
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        _token: '<?php echo e(csrf_token(), false); ?>'
                    },
                    success: function(response) {
                        button.replaceWith('<div class="btn btn-secondary btn-pill">Зайнято</div>');
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });
        });

        $(document).ready(function () {
            $('.date-button').click(function () {
                const date = $(this).data('date');
                const currentUrl = window.location.href;
                const baseUrl = currentUrl.split('?')[0];
                const newUrl = baseUrl + '?date=' + date;

                window.history.pushState({ path: newUrl }, '', newUrl);
                window.location.reload();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\gym.diplom\resources\views/home_page.blade.php ENDPATH**/ ?>